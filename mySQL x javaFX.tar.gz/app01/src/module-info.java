module app01 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql; // <-- Add this line
    requires mysql.connector.java; // <-- Optional, may not be needed unless using services

    opens application to javafx.fxml;
    exports application;
}
