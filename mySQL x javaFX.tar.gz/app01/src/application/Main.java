package application;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import java.sql.*; // Single import for all SQL classes

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            VBox vbox = new VBox(20);
            vbox.setAlignment(Pos.CENTER);

            // UI Components
            ProgressBar pb = new ProgressBar();
            pb.setProgress(-1);
            pb.getStyleClass().add("pb");

            Label lab = new Label("CyberSecurity");
            lab.getStyleClass().add("lab");

            Label par = new Label("Make Your Way!");
            par.getStyleClass().add("par");

            TextField tf = new TextField();
            tf.setPromptText("Enter your name");
            tf.getStyleClass().add("tf");

            PasswordField passwd = new PasswordField();
            passwd.setPromptText("Enter password");
            passwd.getStyleClass().add("passwd");

            TextArea ta = new TextArea();
            ta.setPromptText("Write something...");
            ta.getStyleClass().add("ta");

            Button btn = new Button("LetMeIn!");
            btn.getStyleClass().add("btn");

            // On button click → insert data
            btn.setOnAction(e -> {
                String username = tf.getText();
                String password = passwd.getText();
                String message = ta.getText();
                insertData(username, password, message);
            });

            // Add UI to layout
            vbox.getChildren().addAll(lab, par, tf, passwd, ta, btn, pb);

            // Create scene and load CSS (with null check)
            Scene scene = new Scene(vbox, 800, 600);
            var css = getClass().getResource("application.css");
            if (css != null) {
                scene.getStylesheets().add(css.toExternalForm());
            } else {
                System.out.println("⚠️ application.css not found!");
            }

            primaryStage.setTitle("JavaFX VBox Example");
            primaryStage.setScene(scene);
            primaryStage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Insert data into MySQL
    private void insertData(String username, String password, String message) {
        String url = "jdbc:mysql://localhost:3306/testdb"; // Your DB URL
        String user = "root";                              // Your DB user
        String pass = "as29";                              // Your DB pass

        String query = "INSERT INTO users (username, password, message) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, pass);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, message);
            stmt.executeUpdate();

            System.out.println("✅ Data inserted successfully!");

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args); // Launch JavaFX app
    }
}
